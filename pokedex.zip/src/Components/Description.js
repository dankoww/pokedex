import React from "react";

const Description = ({ heightpok, weightpok }) => {
  return (
    <div className="desc">
      <p>
        <b>Height: {heightpok * 10} cm.</b>
      </p>

      <p>
        <b>Weight: {weightpok * 0.1} kg</b>
      </p>
    </div>
  );
};

export default Description;
